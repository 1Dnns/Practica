//Numpy array shape [5]
//Min -0.180868625641
//Max 0.179117739201
//Number of zeros 0

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
output_bias_t b11[5];
#else
output_bias_t b11[5] = {0.1791177392, -0.1279169321, 0.0384519137, 0.1219400316, -0.1808686256};
#endif

#endif
